package exception;

public class EmployeeNotFoundException extends RuntimeException {

}
