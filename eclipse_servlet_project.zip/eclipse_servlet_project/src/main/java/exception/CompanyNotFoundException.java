package exception;

public class CompanyNotFoundException extends RuntimeException {
	// 멤버가 존재하지 않는 예외
}
