package exception;

public class PositionNotFoundException extends RuntimeException {

}
