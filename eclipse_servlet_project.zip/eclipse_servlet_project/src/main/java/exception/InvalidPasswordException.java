package exception;

public class InvalidPasswordException extends RuntimeException {
	// 유효하지 않은 비밀번호 예외
}
