package exception;

public class BusinessItemNotFoundException extends RuntimeException {

}
