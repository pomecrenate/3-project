package exception;

public class DuplicateIdException extends RuntimeException {
	// 중복 아이디 예외
}
