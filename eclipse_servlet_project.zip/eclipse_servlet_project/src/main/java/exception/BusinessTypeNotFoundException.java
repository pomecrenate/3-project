package exception;

public class BusinessTypeNotFoundException extends RuntimeException {

}
