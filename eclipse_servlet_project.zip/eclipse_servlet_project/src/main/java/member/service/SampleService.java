package member.service;

public class SampleService {

}
