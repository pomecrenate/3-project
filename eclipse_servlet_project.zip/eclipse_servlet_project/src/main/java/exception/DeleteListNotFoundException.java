package exception;

public class DeleteListNotFoundException extends RuntimeException {

}
