package exception;

public class DepartmentNotFoundException extends RuntimeException {

}
