package exception;

public class LoginFailException extends RuntimeException {

}
