package exception;

public class PermissionDeniedException extends RuntimeException {

}
